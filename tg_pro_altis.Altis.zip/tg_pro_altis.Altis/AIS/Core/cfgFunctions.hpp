class AIS_Core
{
    class AIS_Core
    {
        file = "AIS\Core";
        class preInit { preInit = 1; };
        class postInit { postInit = 1; };
		class addAction;
		class aisInitHost;
		class aisInitPlayer;
		class bindEventHandler;
		class createLocalMarker;
		class dynamicText;
		class initEvents;
		class inRange;
		class interaction_Loop;
		class isPlayable;
		class onEachFrame;
		class onNextFrame;
		class progress_ShowBar;
		class progress_ShowBarText;
		class removeonEachFrame;
		class setPosAGLS;
		class setVariables;
		class triggerEvent;
		class waitUntilAndExecute;
		class handleDisconnect;
		class resetOnTeamSwitch;
    };
};