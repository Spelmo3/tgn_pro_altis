class AIS_Effects
{
    class AIS_Effects
    {
        file = "AIS\Effects";
		class preInit { preInit = 1; };
		class bleeding;
		class BloodSplatterScreen;
		class bulletImpact;
		class deleteBloodSplatterScreen;
		class draw3D;
		class garbage;
		class helpScream;
		class injuredMarker;
		class medEquip;
		class removeInjuredMarker;
		class scream;
		class stabil;
		class toggleRadio;
		class posUpdateInjuredMarker;
    };
};